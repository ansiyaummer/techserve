<template>
    <div class="general">
        <v-container>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem, odit!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem, odit!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem, odit!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem, odit!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem, odit!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem, odit!
            lorem10 
        </v-container>
    </div>
</template>
