<template>
    <v-container>
        <v-layout row>
            <v-flex xs12 smxs12 >


            </v-flex>
        </v-layout>
    </v-container>
</template>
<script>
import swal from 'sweetalert'
export default {
    data () {
        return {

        };
    },
    created: function() {

    },
    methods: {

    }
}
</script>
