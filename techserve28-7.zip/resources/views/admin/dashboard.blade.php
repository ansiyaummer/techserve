@extends('layouts.app')

@section('content')
<div>
    <dashboard-component></dashboard-component>
    <example-component></example-component>
</div>

@endsection
