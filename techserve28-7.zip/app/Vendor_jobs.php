<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vendor_jobs extends Model
{
    //
}
