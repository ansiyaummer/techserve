<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class leave_stage extends Model
{
    //
}
