<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class leave_type extends Model
{
    //
}
