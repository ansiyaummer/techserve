<?php

namespace App\Http\Controllers;

use App\leave_stage;
use Illuminate\Http\Request;

class LeaveStageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\leave_stage  $leave_stage
     * @return \Illuminate\Http\Response
     */
    public function show(leave_stage $leave_stage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\leave_stage  $leave_stage
     * @return \Illuminate\Http\Response
     */
    public function edit(leave_stage $leave_stage)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\leave_stage  $leave_stage
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, leave_stage $leave_stage)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\leave_stage  $leave_stage
     * @return \Illuminate\Http\Response
     */
    public function destroy(leave_stage $leave_stage)
    {
        //
    }
}
