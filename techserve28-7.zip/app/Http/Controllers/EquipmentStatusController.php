<?php

namespace App\Http\Controllers;

use App\Equipment_status;
use Illuminate\Http\Request;

class EquipmentStatusController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Equipment_status  $equipment_status
     * @return \Illuminate\Http\Response
     */
    public function show(Equipment_status $equipment_status)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Equipment_status  $equipment_status
     * @return \Illuminate\Http\Response
     */
    public function edit(Equipment_status $equipment_status)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Equipment_status  $equipment_status
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Equipment_status $equipment_status)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Equipment_status  $equipment_status
     * @return \Illuminate\Http\Response
     */
    public function destroy(Equipment_status $equipment_status)
    {
        //
    }
}
