<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Equipment-mcr extends Model
{
  protected $fillable = [
      'name',
  ];
}
